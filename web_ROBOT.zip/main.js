document.addEventListener('DOMContentLoaded', event => {
    // Element selections
    var textoEstado = document.getElementById("estadoConexion");
    var textoPosicionX =document.getElementById("pos_x")
    var textoPosicionY =document.getElementById("pos_y")
    document.getElementById("btn_con").addEventListener("click", connect);
    document.getElementById("btn_dis").addEventListener("click", disconnect);
    document.getElementById("delante").addEventListener("click", () => {
        call_delante_service("delante")
    })
    document.getElementById("sendWaypoints").addEventListener("click",sendGoal)

    // Data object for ROS connection
    /*var data = {
        ros: null,
        rosbridge_address: 'ws://127.0.0.1:9090/',
        connected: false
    };*/

    data = {
        // ros connection
        ros: null,
        rosbridge_address: 'ws://127.0.0.1:9090/',
        connected: false,
        // service information 
          service_busy: false, 
          service_response: ''
      }

    // Connect to ROS
    function connect() {
        data.ros = new ROSLIB.Ros({
            url: data.rosbridge_address
        });

        // Connection established
        data.ros.on("connection", () => {
            data.connected = true;
            console.log("Conexion con ROSBridge correcta");
            textoEstado.textContent = "Conectado";
            suscribir_distancia()
        });

        // Error handling
        data.ros.on("error", (error) => {
            console.log("Se ha producido algun error mientras se intentaba realizar la conexion");
            console.log(error);
            textoEstado.textContent = "no se ha podido Conectar";
        });

        // Connection closed
        data.ros.on("close", () => {
            data.connected = false;
            console.log("Conexion con ROSBridge cerrada");
            textoEstado.textContent = "Desconectado";
        });
    }

    // Disconnect from ROS
    function disconnect() {
        data.ros.close();
        data.connected = false;
        console.log('Clic en botón de desconexión');
        textoEstado.textContent = "Desconectado";
    }
    //mover el robot
    function move() {
        let topic = new ROSLIB.Topic({
            ros: data.ros,
            name: '/cmd_vel',
            messageType: 'geometry_msgs/msg/Twist'
        })
        let message = new ROSLIB.Message({
            linear: {x: 0.1, y: 0, z: 0, },
            angular: {x: 0, y: 0, z: -0.2, },
        })
        topic.publish(message)
    }
    //parar el robot
    function stop() {
        let topic = new ROSLIB.Topic({
            ros: data.ros,
            name: '/cmd_vel',
            messageType: 'geometry_msgs/msg/Twist'
        })
        let message = new ROSLIB.Message({
            linear: {x: 0, y: 0, z: 0, },
            angular: {x: 0, y: 0, z: 0, },
        })
        topic.publish(message)
    }
    //cambiar sentido
    function changeDirection() {
        let topic = new ROSLIB.Topic({
            ros: data.ros,
            name: '/cmd_vel',
            messageType: 'geometry_msgs/msg/Twist'
        });
    
        // Retrieve the current values or set defaults
        let currentLinearX = data.lastMessage ? data.lastMessage.linear.x : 0.1;
        let currentAngularZ = data.lastMessage ? data.lastMessage.angular.z : -0.2;
    
        // Toggle the sign of the components
        let newLinearX = -currentLinearX;
        let newAngularZ = -currentAngularZ;
    
        // Create a new message with toggled values
        let message = new ROSLIB.Message({
            linear: {x: newLinearX, y: 0, z: 0},
            angular: {x: 0, y: 0, z: newAngularZ},
        });
    
        // Publish the new message
        topic.publish(message);
    
        // Optionally, save the last message to toggle it next time
        data.lastMessage = message;
    }
    //metodo de sacar la distancia 
    function suscribir_distancia() {
        let topic = new ROSLIB.Topic({
            ros: data.ros,
            name: '/odom',
            messageType: 'nav_msgs/msg/Odometry'
        })
        
        topic.subscribe((message) => {
            data.position = message.pose.pose.position
                textoPosicionX.textContent = data.position.x.toFixed(2)
                textoPosicionY.textContent = data.position.y.toFixed(2)
        })
    }

    // define the service to be called
    let service = new ROSLIB.Service({
        ros : ros,
        name : '/web_movement_server',
        serviceType : 'FollowWaypoints',
    })

    // define the request
    let request = new ROSLIB.ServiceRequest({
        param1 : 123,
        param2 : 'example of parameter',
    }) 

    // define a callback
    service.callService(request, (result) => {
        console.log('This is the response of the service ')
        console.log(result)

    }, (error) => {
        console.error(error)
    })
    //delante detras derecha izquierda
    function call_delante_service(valor){
        data.service_busy = true
        data.service_response = ''	
    
      //definimos los datos del servicio
        let service = new ROSLIB.Service({
            ros: data.ros,
            name: '/movement',
            serviceType: 'custom_interface/srv/MyMoveMsg'
        })
    
        let request = new ROSLIB.ServiceRequest({
            move: valor
        })
    
        service.callService(request, (result) => {
            data.service_busy = false
            data.service_response = JSON.stringify(result)
            console.log("correcto")
        }, (error) => {
            data.service_busy = false
            console.error(error)
        })	
    }
    //funccion para el waypoints follower 
    function sendGoal(){
        console.log('Sending waypoints1');
        var actionClient = new ROSLIB.ActionClient({
            ros: data.ros,
            serverName: '/follow_waypoints',
            actionName: 'nav2_msgs/action/FollowWaypoints'
        });

        var goal = new ROSLIB.Goal({
            actionClient: actionClient,
            goalMessage: {
                poses: [
                    {
                        header: {
                            frame_id: "map",
                            stamp: { sec: parseInt(Date.now() / 1000), nanosec: ((Date.now() % 1000) * 1e6) }
                        },
                        pose: {
                            position: { x: -1.0, y: 0.5, z: 0.0 },
                            orientation: { x: 0.0, y: 0.0, z: 0.0, w: 1.0 }
                        }
                    },
                    {
                        header: {
                            frame_id: "map",
                            stamp: { sec: parseInt(Date.now() / 1000), nanosec: ((Date.now() % 1000) * 1e6) }
                        },
                        pose: {
                            position: { x: -2.0, y: 0.0, z: 0.0 },
                            orientation: { x: 0.0, y: 0.0, z: 0.0, w: 1.0 }
                        }
                    },
                    {
                        header: {
                            frame_id: "map",
                            stamp: { sec: parseInt(Date.now() / 1000), nanosec: ((Date.now() % 1000) * 1e6) }
                        },
                        pose: {
                            position: { x: -3.3, y: 3.8, z: 0.0 },
                            orientation: { x: 0.0, y: 0.0, z: 0.0, w: 1.0 }
                        }
                    }
                ]
            }
        });
        console.log('Sending waypoints');
        goal.send();

        goal.on('result', function (result) {
            console.log('Received result:', result);
        });
        goal.on('status', function (status) {
            console.log('Status received: ', status);
        });

        goal.on('feedback', function (feedback) {
            console.log('Feedback received: ', feedback);
        });
    }
});
